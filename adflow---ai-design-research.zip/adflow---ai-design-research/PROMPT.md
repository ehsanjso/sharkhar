# Adflow---ai Design Research

## Product
adflow - AI ad creative platform

## Categories Detected
ai-tool

## Reference Apps (Mobbin)

### 01-ui-reference-linear/
**Linear** (web) — 25 screens
→ Clean, minimal aesthetic
→ Use for: ui-reference

### 02-chat-interface-perplexity/
**Perplexity** (web) — 7 screens
→ Best AI chat UX, sources, follow-ups
→ Use for: chat-interface

### 03-onboarding-perplexity/
**Perplexity** (web) — 9 screens
→ Best AI chat UX, sources, follow-ups
→ Use for: onboarding

## Flow Mapping

| Feature | Reference App | Why |
|---------|--------------|-----|
| ui-reference | Linear | Clean, minimal aesthetic |
| chat-interface | Perplexity | Best AI chat UX, sources, follow-ups |
| onboarding | Perplexity | Best AI chat UX, sources, follow-ups |

## Design Galleries

Award-winning websites for visual inspiration:

### galleries/awwwards/
**Awwwards** — 6 references
- Ciridae
- Edwin Le portfolio
- Metoro
- The State of AI at Work
- https://apipass.dev/

### galleries/godly/
**Godly** — 6 references
- Locomotive
- Mike Matas
- Evervault: Customers
- Stripe Sessions
- Mixpanel

### galleries/lapa.ninja/
**Lapa.ninja** — 6 references
- Factory
- World Labs
- General Intelligence Company
- Maze
- AfterQuery

### galleries/land-book/
**Land-book** — 6 references
- Fearn AI
- SKINN | A multidisciplinary branding agency
- Aðgerðaáætlun í loftslagsmálum
- Linie
- Avoice | AI Workspace For Architects | Request a Demo Today

## Prompt for AI Design Agent

> Design a modern web application for "adflow---ai" based on the reference screenshots provided.
>
> **Visual style:** Follow the UI reference folder's design language — clean, minimal, modern.
> Study the gallery references for award-winning visual polish.
>
> **Key patterns to implement:**
> - ui-reference: Reference Linear's patterns from `01-ui-reference-linear/`
> - chat-interface: Reference Perplexity's patterns from `02-chat-interface-perplexity/`
> - onboarding: Reference Perplexity's patterns from `03-onboarding-perplexity/`
> - **Visual polish**: Study the award-winning sites in `galleries/` for animation, typography, and micro-interactions
>
> **Tech stack:** Next.js 14 (App Router), shadcn/ui, Tailwind CSS, TypeScript.
>
> The screenshots are design references for patterns and layouts — don't copy exactly, but match the quality level and UX patterns.
> The gallery sites show what "best in class" looks like for animations and visual design.
